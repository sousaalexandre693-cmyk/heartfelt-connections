# AutoPro Precision Workshop — React + Vite + Tailwind

Projeto React baseado nos ecrãs exportados do Stitch: catálogo de serviços, detalhe do serviço, orçamento/carrinho e finalização com pedido por WhatsApp.

## Executar
1. Instale Node.js 18 ou superior.
2. Abra esta pasta no VS Code/terminal.
3. Execute `npm install`.
4. Execute `npm run dev` e abra o URL apresentado pelo Vite.
5. Para validar produção: `npm run build`.

## Funcionalidades
- Catálogo pesquisável e filtros por categoria.
- Página de detalhe com serviços adicionais opcionais.
- Carrinho com quantidade, remoção e total estimado.
- Dados do cliente, veículo, modalidade, data/hora e observações.
- Resumo completo do pedido enviado por `https://wa.me/351210999888?text=...`.
- Carrinho guardado no `localStorage`.
- Layout responsivo, tipografia Hanken Grotesk / Space Grotesk / JetBrains Mono e paleta próxima do design system Stitch.

## Configuração importante
O número WhatsApp usado está em `src/main.jsx`, na variável `phone` dentro de `sendWhatsApp`. Substitua `351210999888` pelo número real da oficina, apenas com indicativo do país e dígitos (sem `+`, espaços ou símbolos).

Os preços, serviços e taxa de desconto são dados demonstrativos derivados dos ecrãs exportados. Confirme-os antes de colocar o site em produção.
