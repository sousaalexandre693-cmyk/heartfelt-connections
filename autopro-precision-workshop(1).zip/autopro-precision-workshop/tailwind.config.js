/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html','./src/**/*.{js,jsx}'],
  theme: { extend: {
    colors: { background:'#f8f9ff', surface:'#ffffff', 'surface-low':'#eff4ff', 'surface-mid':'#e5eeff', 'surface-high':'#dce9ff', ink:'#0b1c30', muted:'#434655', primary:'#2563eb', 'primary-dark':'#004ac6', orange:'#f97316', line:'#c3c6d7' },
    fontFamily: { sans:['Hanken Grotesk','sans-serif'], display:['Space Grotesk','sans-serif'], mono:['JetBrains Mono','monospace'] },
    boxShadow: { soft:'0 12px 36px rgba(11,28,48,.06)' }
  }},
  plugins:[]
};